Step 1: Make sure you have AlphaConsole installed on BakkesMod (https://bakkesplugins.com/plugins/view/108)
Step 2: Extract this folder
Step 3: Open BakkesMod (application, not ingame)
Step 4: Press "File" -> "Open BakkesMod folder"
Step 5: Go to "data" -> "acplugin" -> "DecalTextures"
Step 6: Put the decal folder in there
Step 7: Start Rocket League
Step 8: Use either the Dominus, Fennec or Octane car
Step 9: Use the "Flames" decal or use the corresponding "Flames" decal in the BakkesMod "Items" tab (press F2, go to "Items" and select for example "Octane: Flames")
Step 10: Open the AlphaConsole menu (F5) and go to the "Cosmetics" tab
Step 11: in the "Decal Texture Mod" section, go to the name of the team that you downloaded and select the corrosponding car (Dominus, Fennec or Octane)





(NOTE FOR VALOR: only put one of the folders in, since they use the same .json file. if you want to put the black version in your game, put that one in your folder 
 and vice versa. you can keep the other folder somewhere else if you want, so you can switch them out if you like. just dont put them both in any of the alpha console folders xD)


PS.: HAVE FUN
